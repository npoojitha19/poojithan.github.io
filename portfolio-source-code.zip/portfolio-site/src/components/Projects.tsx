import React from 'react';
import { resumeData } from '../data/resumeData.ts';

const Projects: React.FC = () => {
  // Client names to display instead of images
  const clients = [
    "AIG",
    "Wells Fargo",
    "AIG"
  ];

  return (
    <section id="projects" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-16 text-blue-900 section-title">Featured Projects</h2>
        
        <div className="space-y-16">
          {resumeData.projects.map((project, index: number) => (
            <div key={index} className="project-card bg-white overflow-hidden">
              <div className="flex flex-col lg:flex-row">
                <div className="lg:w-1/3 p-8 bg-gradient-to-br from-blue-800 to-blue-600 text-white flex flex-col justify-center">
                  <h3 className="text-2xl font-bold mb-4">{project.title}</h3>
                  <p className="text-blue-100 mb-6 font-medium">Client: {clients[index]}</p>
                  <div className="flex flex-wrap gap-2 mt-auto">
                    {project.technologies.slice(0, 5).map((tech: string, idx: number) => (
                      <span key={idx} className="bg-white/10 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 5 && (
                      <span className="bg-white/10 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                        +{project.technologies.length - 5} more
                      </span>
                    )}
                  </div>
                </div>
                <div className="lg:w-2/3 p-8">
                  <p className="text-gray-700 mb-6 text-lg leading-relaxed">{project.description}</p>
                  
                  <h4 className="text-lg font-semibold text-blue-700 mb-4">Key Highlights:</h4>
                  <ul className="list-disc pl-5 mb-6 text-gray-700 space-y-2">
                    {project.highlights.map((highlight: string, idx: number) => (
                      <li key={idx} className="mb-1">{highlight}</li>
                    ))}
                  </ul>
                  
                  <div>
                    <h4 className="text-lg font-semibold text-blue-700 mb-4">All Technologies Used:</h4>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech: string, idx: number) => (
                        <span key={idx} className="skill-tag">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
