# Poojitha N - Portfolio Website

This is a professional portfolio website for Poojitha N, a Java Full Stack Developer with over 8 years of experience.

## Features

- Responsive design for both desktop and mobile viewing
- Professional, corporate styling
- Showcases skills, projects, experience, and certifications
- Custom-generated visual examples of work

## Project Structure

- `src/` - Source code directory
  - `components/` - React components for each section
  - `data/` - TypeScript data files
  - `assets/` - Images and other static assets

## Getting Started

### Prerequisites

- Node.js (v16+)
- npm or pnpm

### Installation

1. Clone the repository
2. Install dependencies:
```
npm install
```
or
```
pnpm install
```

### Development

To run the development server:
```
npm run dev
```
or
```
pnpm run dev
```

### Building for Production

To build the project for production:
```
npm run build
```
or
```
pnpm run build
```

The build output will be in the `dist/` directory.

## Deployment

The `dist/` directory contains all files needed for deployment. You can deploy these files to any static hosting service like:

- GitHub Pages
- Netlify
- Vercel
- AWS S3
- Firebase Hosting

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- Vite

## License

This project is licensed for personal use only.
