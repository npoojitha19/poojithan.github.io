import React from 'react';
import { resumeData } from '../data/resumeData.ts';

const Certifications: React.FC = () => {
  return (
    <section id="certifications" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-16 text-blue-900 section-title">Certifications</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {resumeData.certifications.map((cert: string, index: number) => (
            <div key={index} className="certification-card hover:bg-gradient-to-br hover:from-white hover:to-blue-50">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-400 rounded-lg flex items-center justify-center shadow-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <h3 className="text-lg font-semibold text-center text-blue-800">{cert}</h3>
              <p className="text-center text-gray-500 mt-3 text-sm">Verified Professional Certification</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <p className="text-gray-600">
            All certifications are validated and maintained current to ensure the highest level of professional standards.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Certifications;
