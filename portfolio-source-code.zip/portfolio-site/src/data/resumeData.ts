interface Skill {
  programming: string[];
  backend: string[];
  frontend: string[];
  devops: string[];
  messaging: string[];
  databases: string[];
  security: string[];
  testing: string[];
  versionControl: string[];
  monitoring: string[];
  agile: string[];
  documentation: string[];
}

interface Project {
  title: string;
  description: string;
  highlights: string[];
  technologies: string[];
  image: string;
}

interface Experience {
  company: string;
  position: string;
  period: string;
  responsibilities: string[];
}

interface Contact {
  email: string;
  linkedin: string;
  github: string;
}

interface ResumeData {
  name: string;
  title: string;
  summary: string;
  skills: Skill;
  projects: Project[];
  experience: Experience[];
  certifications: string[];
  contact: Contact;
}

export const resumeData: ResumeData = {
  name: "Poojitha N",
  title: "Java Full Stack Developer",
  summary: "Experienced Java Full Stack Developer with over 8 years of expertise in building scalable, secure, and high-performance applications. Proficient in Java, Spring Boot, Microservices, and frontend technologies including React and Angular. Strong background in cloud computing, containerization, and CI/CD pipelines.",
  
  skills: {
    programming: ["Java", "Java 8+", "JavaScript", "TypeScript", "SQL", "HTML5", "CSS3", "SASS", "Bootstrap"],
    backend: ["Spring Boot", "Spring MVC", "Spring Security", "Spring Cloud", "Spring WebFlux", "Microservices", "RESTful APIs", "SOAP Web Services", "JPA/Hibernate"],
    frontend: ["React.js (Hooks, Context API)", "Redux", "Angular", "HTML5", "CSS3", "JavaScript (ES6)", "Bootstrap", "Material UI"],
    devops: ["AWS (EC2, S3, Lambda, RDS, DynamoDB, SQS)", "Azure (AKS, Blob Storage, Key Vault)", "Docker", "Kubernetes", "Terraform", "Ansible", "Jenkins", "CI/CD pipelines"],
    messaging: ["Apache Kafka", "RabbitMQ", "AWS SQS", "Azure Service Bus", "Event-Driven Architecture"],
    databases: ["MySQL", "PostgreSQL", "Oracle", "MS SQL Server", "MongoDB", "Cassandra", "Cosmos DB", "DynamoDB"],
    security: ["OAuth 2.0", "JWT", "Spring Security", "Role-Based Access Control (RBAC)", "SSO", "LDAP Integration"],
    testing: ["JUnit", "Mockito", "Selenium", "Cucumber", "TestNG", "Postman", "SoapUI", "Swagger"],
    versionControl: ["Git", "GitHub", "Bitbucket", "Subversion (SVN)"],
    monitoring: ["Prometheus", "Grafana", "Datadog", "Splunk", "ELK Stack", "CloudWatch"],
    agile: ["Scrum", "Kanban", "TDD", "Pair Programming", "Jira", "Confluence"],
    documentation: ["Swagger", "OpenAPI", "GraphQL"]
  },
  
  projects: [
    {
      title: "Insurance Platform",
      description: "A comprehensive insurance platform for managing accident data with secure API endpoints and responsive interfaces.",
      highlights: [
        "Implemented OAuth 2.0 and JWT for secure API endpoints and user role management",
        "Integrated AWS services (S3, Lambda) for enhanced scalability and availability",
        "Built responsive front-end interfaces using React.js with Redux",
        "Utilized MongoDB and PostgreSQL for optimized data storage and queries",
        "Ensured HIPAA compliance and data security standards"
      ],
      technologies: ["Java", "Spring Boot", "React.js", "Redux", "AWS", "MongoDB", "PostgreSQL", "OAuth 2.0", "JWT", "Microservices"],
      image: "insurance-platform.jpg"
    },
    {
      title: "Banking Platform",
      description: "A secure and efficient banking platform for processing customer transactions, managing accounts, and handling loan applications with high availability and reliability.",
      highlights: [
        "Developed RESTful APIs using Spring Boot for integrated banking services",
        "Created dynamic single-page applications using Angular and React.js",
        "Integrated AWS RDS and DynamoDB for high-availability data storage",
        "Implemented Kafka for event-driven transaction processing and real-time alerts",
        "Built microservices for authentication, account management, and loan processing",
        "Established CI/CD pipelines using Jenkins and GitLab CI"
      ],
      technologies: ["Spring Boot", "RESTful APIs", "Angular", "React.js", "AWS RDS", "DynamoDB", "Kafka", "Microservices", "Jenkins", "GitLab CI", "OAuth2", "JWT", "Kubernetes"],
      image: "banking-platform.jpg"
    },
    {
      title: "Financial Management System",
      description: "A secure, cloud-native financial management system for processing transactions, account management, and reporting with high availability.",
      highlights: [
        "Built microservices using Spring Boot and Java 1.8",
        "Developed responsive SPAs using Angular, TypeScript, and Bootstrap",
        "Implemented OAuth2 authentication for API security",
        "Designed asynchronous messaging with Apache Kafka",
        "Deployed Dockerized microservices with Kubernetes",
        "Migrated infrastructure to Azure cloud services"
      ],
      technologies: ["Java 1.8", "Spring Boot", "Spring Cloud", "Angular", "TypeScript", "Node.js", "OAuth2", "Kafka", "MongoDB", "Docker", "Kubernetes", "Azure", "AWS Lambda", "DynamoDB"],
      image: "financial-platform.jpg"
    }
  ],
  
  experience: [
    {
      company: "Recent Employment",
      position: "Senior Java Full Stack Developer",
      period: "Current",
      responsibilities: [
        "Implement high-performance, scalable microservices",
        "Optimize services for performance and efficiency",
        "Build backend REST services with high availability",
        "Develop automated tests using JUnit, Mockito, and Selenium",
        "Implement real-time notifications using Kafka and AWS SNS",
        "Integrate third-party systems and APIs",
        "Develop API documentation using Swagger",
        "Contribute to Agile Scrum ceremonies",
        "Ensure GDPR and HIPAA compliance",
        "Implement Docker containers for consistent environments",
        "Use Jenkins for CI/CD automation",
        "Provide production support and troubleshooting"
      ]
    },
    {
      company: "Previous Employment",
      position: "Java Full Stack Developer",
      period: "Prior Experience",
      responsibilities: [
        "Participated in full SDLC processes",
        "Gathered requirements and implemented features using Agile methodology",
        "Developed core logic using Java 8",
        "Created REST/SOAP web services using Spring",
        "Automated and configured AWS and Azure environments",
        "Developed React JS components integrated with Angular",
        "Used Hibernate for ORM solutions",
        "Implemented JPA frameworks and APIs"
      ]
    }
  ],
  
  certifications: [
    "AWS Certified Solution Architect – Associate",
    "SQL Certification – Hacker Rank",
    "Java Certification – Hacker Rank",
    "Certified Kubernetes Administrator (CKA)"
  ],
  
  contact: {
    email: "contact@poojitha-n.com",
    linkedin: "www.linkedin.com/in/poojitha-n-5439a0271",
    github: "github.com/poojitha-n"
  }
};
