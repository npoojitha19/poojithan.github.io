import React from 'react';
import { resumeData } from '../data/resumeData.ts';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 contact-gradient text-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-16 section-title">Contact Information</h2>
        
        <div className="max-w-4xl mx-auto contact-card">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center mb-6 shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold mb-3">Email</h3>
              <a 
                href={`mailto:${resumeData.contact.email}`} 
                className="text-blue-100 hover:text-white transition-colors duration-300 text-lg"
              >
                {resumeData.contact.email}
              </a>
              <p className="mt-4 text-blue-200 text-sm text-center">
                Available for project inquiries and professional opportunities
              </p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center mb-6 shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v7h4v-7M4 8a4 4 0 118 0v1H4V8z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold mb-3">LinkedIn</h3>
              <a 
                href={`https://${resumeData.contact.linkedin}`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-100 hover:text-white transition-colors duration-300 text-lg"
              >
                Connect on LinkedIn
              </a>
              <p className="mt-4 text-blue-200 text-sm text-center">
                Professional network for collaboration and industry updates
              </p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center mb-6 shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold mb-3">GitHub</h3>
              <a 
                href={`https://${resumeData.contact.github}`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-100 hover:text-white transition-colors duration-300 text-lg"
              >
                View GitHub Profile
              </a>
              <p className="mt-4 text-blue-200 text-sm text-center">
                Code repositories and open source contributions
              </p>
            </div>
          </div>
          
          <div className="mt-16 text-center">
            <p className="text-lg text-blue-100">
              Clients: AIG • Wells Fargo
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
