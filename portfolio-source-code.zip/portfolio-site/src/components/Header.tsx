import React from 'react';
import { resumeData } from '../data/resumeData.ts';

const Header: React.FC = () => {
  return (
    <header className="header-gradient text-white py-20">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-10 md:mb-0 text-center md:text-left">
            <h1 className="text-5xl md:text-6xl font-bold mb-4 tracking-tight">{resumeData.name}</h1>
            <h2 className="text-2xl md:text-3xl text-blue-100 mb-6 font-medium">{resumeData.title}</h2>
            <p className="max-w-2xl text-gray-100 text-lg leading-relaxed">{resumeData.summary}</p>
            <div className="mt-8 flex flex-wrap gap-4 justify-center md:justify-start">
              <a 
                href={`https://${resumeData.contact.linkedin}`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="btn btn-primary"
              >
                Connect on LinkedIn
              </a>
              <a 
                href={`https://${resumeData.contact.github}`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="btn bg-white text-blue-900 hover:bg-gray-100"
              >
                View GitHub
              </a>
            </div>
          </div>
          <div className="flex flex-col items-center">
            <div className="bg-white/10 backdrop-blur-sm rounded-full p-2 shadow-xl overflow-hidden">
              <img 
                src="/assets/profile.jpg" 
                alt="Poojitha N" 
                className="w-40 h-40 rounded-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
