import React, { useState } from 'react';

const Navigation: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center py-5">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-900 to-blue-600 text-transparent bg-clip-text">
            Poojitha N
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#skills" className="nav-link text-gray-700 hover:text-blue-900 transition-colors duration-300 font-medium">Skills</a>
            <a href="#projects" className="nav-link text-gray-700 hover:text-blue-900 transition-colors duration-300 font-medium">Projects</a>
            <a href="#experience" className="nav-link text-gray-700 hover:text-blue-900 transition-colors duration-300 font-medium">Experience</a>
            <a href="#certifications" className="nav-link text-gray-700 hover:text-blue-900 transition-colors duration-300 font-medium">Certifications</a>
            <a href="#contact" className="nav-link text-gray-700 hover:text-blue-900 transition-colors duration-300 font-medium">Contact</a>
          </div>
          
          <div className="md:hidden">
            <button 
              className="text-gray-700 hover:text-blue-900 focus:outline-none"
              onClick={toggleMenu}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 px-2 space-y-3 border-t border-gray-200">
            <a href="#skills" className="block py-2 px-4 text-gray-700 hover:bg-blue-50 hover:text-blue-900 rounded-md transition-colors duration-300">Skills</a>
            <a href="#projects" className="block py-2 px-4 text-gray-700 hover:bg-blue-50 hover:text-blue-900 rounded-md transition-colors duration-300">Projects</a>
            <a href="#experience" className="block py-2 px-4 text-gray-700 hover:bg-blue-50 hover:text-blue-900 rounded-md transition-colors duration-300">Experience</a>
            <a href="#certifications" className="block py-2 px-4 text-gray-700 hover:bg-blue-50 hover:text-blue-900 rounded-md transition-colors duration-300">Certifications</a>
            <a href="#contact" className="block py-2 px-4 text-gray-700 hover:bg-blue-50 hover:text-blue-900 rounded-md transition-colors duration-300">Contact</a>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
