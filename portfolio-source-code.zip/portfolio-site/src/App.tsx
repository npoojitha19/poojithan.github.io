import Header from './components/Header';
import Navigation from './components/Navigation';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Certifications from './components/Certifications';
import Contact from './components/Contact';

function App() {
  return (
    <div className="App">
      <Header />
      <Navigation />
      <main>
        <Skills />
        <Projects />
        <Experience />
        <Certifications />
        <Contact />
      </main>
      <footer className="bg-gray-800 text-white py-6 text-center">
        <div className="container mx-auto px-4">
          <p>&copy; {new Date().getFullYear()} Poojitha N. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
